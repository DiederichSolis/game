/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.util.ArrayList;
import java.util.Scanner;
import model.Cazador;
import model.Gue;
import model.VillaintypeB;
import model.explorer;
import model.villainboss;
import model.villaintypeA;

/**
 *
 * @author diederich josue emidio solis lopez 22952
 */
public class Game {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner e = new Scanner(System.in);
        System.out.println("Bienvenido!!");
        /*
        se crean los arreglos para ir guardando y actualizando los datos de cada villano y heroe
        */
         ArrayList<VillaintypeB>  villanoB_array  = new ArrayList<VillaintypeB>();
       ArrayList<villaintypeA> villanoA_array  = new ArrayList<villaintypeA>();
       ArrayList<villainboss>  villanoboss = new ArrayList<villainboss>();
      ArrayList<Gue>  guerrero_array= new ArrayList<Gue>();
      ArrayList<explorer>  explorador_array= new ArrayList<explorer>();
         ArrayList<Cazador>  cazador_array = new ArrayList<Cazador>();
      /*
      Se establece el valor de cada atributo tanto para los villanos y heroes
      */
       int op=1;
        int live = 100;
               int atack = 20;
               String name = "Raidboss";
               String NamespH = "Liberar";
               int espH = 30;
               int shield = 10;
               int liveA = 100;
               int atackA = 20;
               String nameA = "Invasor";
               String NamespHA = "Acido";
               int espHA = 30;
                int liveBoss = 150;
               int atackBoss = 30;
               String nameBoss = "Invasor SUPREMO";
               String NamespHBoss = "ultimate";
               int espHBoss = 35;
               String Namextraesp= "devastador";
               int extraesp= 35;
               villaintypeA villanoA= new villaintypeA(liveA,atackA,nameA,NamespHA,espHA);
               VillaintypeB  villanoB = new VillaintypeB(live,atack,name,NamespH, espH, shield);
               villainboss villanoBoss = new villainboss(liveBoss,atackBoss,nameBoss,NamespHBoss,espHBoss,Namextraesp,extraesp);
                villanoB_array.add(villanoB);
                villanoA_array.add(villanoA);
                villanoboss.add(villanoBoss);
               int livexp = 100;
               int atackexp = 20;
               String itemsname ="Sanacion";
               String itemsname1="Power";
               String namexp = "Explorador";
               int items1exp = 10;
               int items2exp= 30;
               
               int livegue = 100;
               int atackgue = 20;
               String itemsnamegue ="Sanacion";
               String namegue= "Guerreo";
               
               String namecazador= "Cazador";
               int livecaza = 100;
               int atackcaza = 20;
               String itemsnamecaza ="Acompañante";

               
                  int items3gue=30;
                   explorer explorador = new explorer(livexp,atackexp,itemsname,itemsname1,namexp,items1exp,items2exp);
                   Gue guerrero = new Gue(livegue,atackgue,itemsnamegue,namegue,items3gue);
               guerrero_array.add(guerrero);
               explorador_array.add(explorador);
        while(op != 2){
           Menu(); 
           op = e.nextInt();
              String P1 = "";
            String P2="";
                String P3="";
            String message="";
            String message2="";
           if (op==1){
               System.out.println("Advertencia, dependiendo la seleccion del jugador 1 el jugador 2 tendra un personaje seleccionado");
               System.out.println("Jugador 1, seleccione que tipo de jugador desea 1.Cazador,2.Explorador, 3.Guerrero");             
               int sel  = e.nextInt();
               if (sel == 1){
               
                  P1 = "Jugador 1 es un cazador";
                   P2="Jugador 2 es un guerrero";
                    P3="Nadie es explorador";
                  
               }if(sel == 2){
                   
                  P1="Jugador 1 es un guerrero";
                   P2="Jugador 2 es un cazador";
                 P3="Nadie es explorador";
                           
               }
               System.out.println("");
               System.out.println(P1);
        System.out.println("Favor de escoger una frase para su personaje:");
                   System.out.println("1.Somos superiores 2.NO podran contra nosotros");
                   int sele = e.nextInt();
                   if (sele== 1){
                      message = "Somos superiores";
                   }else{
                      message = "NO podran contra nosotros";
                   }
                   System.out.println("");
                  System.out.println(P2);
               
                    System.out.println("1.Somos superiores 2.NO podran contra nosotros");
                   int sele1 = e.nextInt();
                   if (sele1== 1){
                        message2 = "Somos superiores";
                   }else{
                      message2 = "NO podran contra nosotros";
                   }
                   /*
                   Le muestra al usuario las caracteristicas de cada villano y heroe para que se enteren o sepan que contiene cada uno.
                   */
                System.out.println("");
               System.out.println("Para poder completar la mision deberan derrotar a los enemigos  ");
               System.out.println("Sus enemigos son muy poderosos, tenga mucho cuidado, les deseamos exitos, contamos con ustedes");
               System.out.println("para ayudarlos un poco sus enemigos son los siguientes:");
               System.out.println("");
               System.out.println(nameA);
               System.out.println("Los datos del enemigo son: ");
               System.out.println("vida: "+liveA);
               System.out.println("daño de ataque: "+atackA);
               System.out.println("Habilidad especial: "+NamespHA);
               System.out.println("Daño de la habilidad especial: "+espHA);
               System.out.println("");
               System.out.println(name);
               System.out.println("Los datos del enemigo son: ");
               System.out.println("vida: "+live);
               System.out.println("daño de ataque: "+atack);
               System.out.println("Habilidad especial: "+NamespH);
               System.out.println("Daño de la habilidad especial: "+espH);
               System.out.println("Este villano cuenta con escudo de: "+shield);
               System.out.println("");
               int cant1 = 2;
               System.out.println("Hey!!! no te preocupes por ellos, ustedes tambien son poderosos");
               System.out.println("Sus datos son los siguientes");
               System.out.println("Para el heroe Guerrero");
               System.out.println("Vida: "+livegue);
               System.out.println("Daño de ataque: "+atackgue);
               System.out.println("Habilidad especial: "+itemsnamegue);
               System.out.println("Sanacion de: "+items3gue);
               System.out.println("Cantidad de usos para items: "+cant1);
               System.out.println("");
               int cant2= 1;
               System.out.println("Para el heroe Explorador");
               System.out.println("Vida: "+livexp);
               System.out.println("Daño de ataque: "+atackexp);
               System.out.println("Habilidad especial: "+itemsname);
               System.out.println("Segunda Habilidad especial: "+itemsname1);
               System.out.println("Sanacion de: "+items1exp);
               System.out.println("Daño de la segunda habilidad especial: "+items2exp);
                System.out.println("Cantidad de usos para items: "+cant2);
                 System.out.println("");
                System.out.println("Para el heroe Cazador");
               System.out.println("Vida: "+livecaza);
               System.out.println("Daño de ataque: "+atackcaza);
               System.out.println("Habilidad especial: "+itemsnamecaza);
               System.out.println("Daño de la habilidad especial: "+10);
                System.out.println("Cantidad de usos para items: "+cant2);
                
                
                      
               System.out.println("");
               System.out.println("Listo para combatir!!, Comienza la batalla!!");
               System.out.println("Turno del jugador 1");
                System.out.println("Que deseas realizar 1.ataque normal 2.habilidad especial");
                int op1 = e.nextInt();
                System.out.println("Villano a combatir Raid boss, presione 1");
                int op1v=e.nextInt();
                
                if ("Jugador 1 es un cazador".equals(P1)){
                  if (op1==1 && op1v==1){
                      
                    System.out.println("Ataque hacia raid boss, el daño causado es de: "+atackcaza);
                    System.out.println("Ataque hacia raid boss por tu acompañante, el daño causado es de: "+atackcaza);
                      System.out.println("El enemigo a usado Escudo");
                      System.out.println("Los datos actuales de los enemigos son: ");
                      System.out.println(name);
                      live=live-30+10;
                      System.out.println("vida: "+live);
                      System.out.println("No te preocupes el enemigo ya no tiene escudo");
                      System.out.println("");
                      System.out.println("Ten cuidado!! el enemigo va atacar ");
                      System.out.println("El enemigo te ha herido");
                      livegue = livegue -20;
                      System.out.println("Tu vida actual es de :"+livegue);
                      
                   
                     }
                    if (op1==2 && op1v==1){
                      cant1 = cant1-1;
                    System.out.println("Uso de item, el daño causado es de: "+items3gue);
                        System.out.println("te queda un item");
                      System.out.println("El enemigo a usado Escudo");
                      System.out.println("Los datos actuales del villano raid boss: ");
                      System.out.println(name);
                      live=live-30+10;
                      System.out.println("vida: "+live);
                      System.out.println("No te preocupes el enemigo ya no tiene escudo");
                      System.out.println("");
                      System.out.println("Ten cuidado!! el enemigo va atacar ");
                      System.out.println("El enemigo te ha herido");
                      livegue = livegue -20;
                      System.out.println("Tu vida actual es de :"+livegue);
                      
                   
                     }
               
                }
                System.out.println("");
                System.out.println("Turno del jugador 2");
                System.out.println("Que deseas realizar 1.ataque normal 2.habilidad especial");
                int op2 = e.nextInt();
                  System.out.println("Villano a combatir raidboss, presione 1");
                int op2v=e.nextInt();
                if ("Jugador 1 es un cazador".equals(P1)){
                  if (op2==1 && op2v==1){
                      
                    System.out.println("Ataque hacia Raid boss, el daño causado es de: "+atackexp);
                      System.out.println("Los datos actuales de los enemigos son: ");
                      System.out.println(name);
                         live=live-20;
                      System.out.println("vida: "+live);
                      System.out.println("No te preocupes el enemigo ya no tiene escudo");
                      System.out.println("");
                      System.out.println("Ten cuidado!! el enemigo va atacar ");
                      System.out.println("El enemigo te ha herido");
                      livexp = livexp -20;
                      System.out.println("Tu vida actual es de :"+livexp);
                      
                   
                     }
                    if (op2==2 && op2v==1){
                      cant2 = cant2-1;
                    System.out.println("Uso de item, el daño causado es de: "+items2exp);
                        System.out.println("Acabas de usar tu unico item");
                      System.out.println("Los datos actuales de los enemigos son: ");
                      System.out.println(name);
                         live=live-30;
                      System.out.println("vida: "+live);
                      System.out.println("");
                      System.out.println("Ten cuidado!! el enemigo va atacar ");
                      System.out.println("El enemigo te ha herido");
                      livexp = livexp -20;
                      System.out.println("Tu vida actual es de :"+livexp);
                      
                   
                     }
                   
               
                }
                System.out.println("");
           System.out.println("Turno del jugador 1");
                System.out.println("Que deseas realizar 1.ataque normal ");
                int op3 = e.nextInt();
                System.out.println("Villano a combatir Raid boss, presione 1");
                int op3v=e.nextInt();
                 if (op3==1 && op3v==1){
                      
                    System.out.println("Ataque hacia Raid boss, el daño causado es de: "+atackgue);
                      System.out.println("Los datos actuales de los enemigos son: ");
                      System.out.println(name);
                      live=live-20;
                      System.out.println("vida: "+live);
                      System.out.println("");
                      System.out.println("Ten cuidado!! el enemigo va atacar ");
                      System.out.println("El enemigo te ha herido");
                      livegue = livegue -20;
                      System.out.println("Tu vida actual es de :"+livegue);
                      
                   if(live<=0){
                       System.out.println("");
                       System.out.println("Felicidades derrotaron al enemigo, Raid boss!!");
                       System.out.println("Gracias por jugar esperemos que sigas jugando");
                       break;
                   }
             
                 }
                 System.out.println("");
         System.out.println("Turno del jugador 2");
                System.out.println("Que deseas realizar 1.ataque normal ");
                int op4 = e.nextInt();
                System.out.println("Villano a combatir destructor, presione 1");
                int op4v=e.nextInt();
                 if (op4==1 && op4v==1){
                      
                    System.out.println("Ataque hacia Destructor, el daño causado es de: "+atackexp);
                      System.out.println("Los datos actuales de los enemigos son: ");
                      System.out.println(name);
                      live=live-20;
                      System.out.println("vida: "+live);
                      System.out.println("");
                      System.out.println("Ten cuidado!! el enemigo va atacar ");
                      System.out.println("El enemigo te ha herido");
                      livexp = livexp -20;
                      System.out.println("Tu vida actual es de :"+livexp);
                      
                   if(live<=0){
                       System.out.println("");
                       System.out.println("Felicidades derrotaron al enemigo!!");
                       System.out.println("Gracias por jugar esperemos que sigas jugando");
                       break;
                   }
             
                 }
           System.out.println("");
           System.out.println("Turno del jugador 1");
                System.out.println("Que deseas realizar 1.ataque normal ");
                int op5 = e.nextInt();
                System.out.println("Villano a combatir destructor, presione 1");
                int op5v=e.nextInt();
                 if (op5==1 && op5v==1){
                      
                    System.out.println("Ataque hacia Destructor, el daño causado es de: "+atackgue);
                      System.out.println("Los datos actuales de los enemigos son: ");
                      System.out.println(name);
                      live=live-20;
                      System.out.println("vida: "+live);
                      System.out.println("");
                     
                      
                   if(live<=0){
                       System.out.println("");
                       System.out.println("Felicidades derrotaron al enemigo!!");
                       System.out.println("Gracias por jugar esperemos que sigas jugando");
                       break;
                   }
             
                 }
           }
           
           
           if(op==2){
          break;
               
           }
           
        }
    }
    /**
     * Se crea metodo para el menu
     */
public static void Menu(){
       System.out.println(" ");
       System.out.println("--------------------------------------------------");
       System.out.println("Eliga una opcion"); 
       System.out.println("1.Start Game");
       System.out.println("2.Salir");
       System.out.println("-----------------------------------------------------");
}     
/**
 * 
 * @param live
 * @param atack
 * @return live retorna la vida actual del villano con los cambio hecho por los ataques
 */
  public static int batallah1v1(int live, int atack){
      live = live -20;
     live=live+10;
      return live;
  }
  /**
   * 
   * @param live
   * @param atack
   * @return live retorna la vida actual del villano con los cambio hecho por los ataques
   */
    public static int batallah1v11(int live, int atack){
      live = live -30;
     live=live+10;
      return live;
  }

}
