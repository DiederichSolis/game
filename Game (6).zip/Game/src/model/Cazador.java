/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author diede
 */
public class Cazador extends hero{
      String Acompañante;
      /**
       * 
       * @param live
       * @param atack
       * @param itemsname
       * @param name
       * @param item3
       * @param Acompañante 
       */
    public Cazador(int live, int atack, String itemsname, String name, int item3,String Acompañante) {
      
        
        super(live, atack, itemsname,  name);
        this.Acompañante=Acompañante;
        
    }

    public String getAcompañante() {
        return Acompañante;
    }

    public void setAcompañante(String Acompañante) {
        this.Acompañante = Acompañante;
    }
    
}
