/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author diederich solis 22952
 */

/*
Se creo clase hija para clase padre villain, se establecio su constructor con los nuevos atributos
*/
public class villainboss extends Villain{
    private String Namextraesp;
    private int extraesp;
    public villainboss(int live, int atack, String name, String NamespH, int espH, String Namextraesp, int extraesp) {
        super(live, atack, name, NamespH, espH);
        this.Namextraesp = Namextraesp;
        this.extraesp = extraesp;
                
    }
/*
Se crearon sus respectivos getter y setter de cada atributo
*/
    public void setExtraesp(int extraesp) {
        this.extraesp = extraesp;
    }

    public int getExtraesp() {
        return extraesp;
    }

    public void setNamextraesp(String Namextraesp) {
        this.Namextraesp = Namextraesp;
    }

    public String getNamextraesp() {
        return Namextraesp;
    }
    
}
