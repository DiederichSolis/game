/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author diederich solis 22952
 */

/*
Se creo clase hija para clase padre villain, se establecio su constructor con los nuevos atributos
*/
public class villaintypeA extends Villain {
    
    public villaintypeA(int live, int atack, String name, String NamespH, int espH) {
        super(live, atack, name, NamespH, espH);
    }
    
}
