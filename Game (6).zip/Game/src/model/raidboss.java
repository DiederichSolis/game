/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author diede
 */

public class raidboss extends Villain {
    /**
     * 
     * @param live
     * @param atack
     * @param name
     * @param NamespH
     * @param espH 
     */
    public raidboss(int live, int atack, String name, String NamespH, int espH) {
        super(live, atack, name, NamespH, espH);
    }
}
