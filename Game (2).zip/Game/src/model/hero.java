/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author diede
 */
public class hero {
    private int live;
    private int atack;
    private String itemsname;
    private String name;

    
   public hero(int live, int atack, String itemsname, String name){
       this.atack = atack;
       this.live = live;
       this.itemsname = itemsname;
      
       
    
       this.name = name;
   }

    public void setLive(int live) {
        this.live = live;
    }

    public void setAtack(int atack) {
        this.atack = atack;
    }

    public void setItemsname(String itemsname) {
        this.itemsname = itemsname;
    }

    

    public void setName(String name) {
        this.name = name;
    }

    

    

    public int getLive() {
        return live;
    }

    public int getAtack() {
        return atack;
    }

    public String getItemsname() {
        return itemsname;
    }

  

    public String getName() {
        return name;
    }

   
    
}
