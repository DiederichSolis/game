/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author diede
 */
public class explorer extends hero{
    private int items1;
    private int items2;
    private String itemsname1;
    public explorer(int live, int atack, String itemsname,String itemsname1,  String name, int items1,int items2) {
        super(live, atack, itemsname, name);
    this.items1 = items1;
    this.items2= items2;
    this.itemsname1=itemsname1;
    
            }

    public String getItemsname1() {
        return itemsname1;
    }

    public void setItemsname1(String itemsname1) {
        this.itemsname1 = itemsname1;
    }

    
    public void setItems1(int items1) {
        this.items1= items1;
    }

    public void setItems2(int items2) {
        this.items2 = items2;
    }

    public int getItems1() {
        return items1;
    }

    public int getItems2() {
        return items2;
    }
    
}
