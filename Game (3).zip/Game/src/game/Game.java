/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.util.ArrayList;
import java.util.Scanner;
import model.Gue;
import model.VillaintypeB;
import model.explorer;
import model.villainboss;
import model.villaintypeA;

/**
 *
 * @author diederich josue emidio solis lopez 22952
 */
public class Game {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner e = new Scanner(System.in);
        System.out.println("Bienvenido!!");
         ArrayList<VillaintypeB>  villanoB_array  = new ArrayList<VillaintypeB>();
       ArrayList<villaintypeA> villanoA_array  = new ArrayList<villaintypeA>();
       ArrayList<villainboss>  villanoboss = new ArrayList<villainboss>();
      ArrayList<Gue>  guerrero_array= new ArrayList<Gue>();
      ArrayList<explorer>  explorador_array= new ArrayList<explorer>();
       int op=1;
        int live = 100;
               int atack = 10;
               String name = "Destructor";
               String NamespH = "Veneno";
               int espH = 15;
               int shield = 10;
               int liveA = 100;
               int atackA = 10;
               String nameA = "Invasor";
               String NamespHA = "Acido";
               int espHA = 15;
                int liveBoss = 150;
               int atackBoss = 15;
               String nameBoss = "Invasor supremo";
               String NamespHBoss = "ultimate";
               int espHBoss = 20;
               String Namextraesp= "devastador";
               int extraesp= 25;
               villaintypeA villanoA= new villaintypeA(liveA,atackA,nameA,NamespHA,espHA);
               VillaintypeB  villanoB = new VillaintypeB(live,atack,name,NamespH, espH, shield);
               villainboss villanoBoss = new villainboss(liveBoss,atackBoss,nameBoss,NamespHBoss,espHBoss,Namextraesp,extraesp);
                villanoB_array.add(villanoB);
                villanoA_array.add(villanoA);
                villanoboss.add(villanoBoss);
               int livexp = 100;
               int atackexp = 10;
               String itemsname ="Sanacion";
               String itemsname1="Power";
               String namexp = "Explorador";
               int items1exp = 10;
               int items2exp= 10;
               
               int livegue = 100;
               int atackgue = 20;
               String itemsnamegue ="Sanacion";
               String namegue= "Guerreo";
                  int items3gue=10;
                   explorer explorador = new explorer(livexp,atackexp,itemsname,itemsname1,namexp,items1exp,items2exp);
                   Gue guerrero = new Gue(livegue,atackgue,itemsnamegue,namegue,items3gue);
               guerrero_array.add(guerrero);
               explorador_array.add(explorador);
        while(op != 2){
           Menu(); 
           op = e.nextInt();
              String P1 = "";
            String P2="";
            String message="";
            String message2="";
           if (op==1){
               System.out.println("Advertencia, dependiendo la seleccion del jugador 1 el jugador 2 tendra un personaje seleccionado");
               System.out.println("Jugador 1, seleccione que tipo de jugador desea 1.Guerrero,2.Explorador");             
               int sel  = e.nextInt();
               if (sel == 1){
               
                  P1 = "Jugador 1 es un guerrero";
                   P2="Jugador 2 es un explorador";
                  
               }if(sel == 2){
                   
                  P1="Jugador 1 es un explorador";
                   P2="Jugador 2 es un guerrero";
               
                           
               }
               System.out.println("");
               System.out.println(P1);
        System.out.println("Favor de escoger una frase para su personaje:");
                   System.out.println("1.Somos superiores 2.NO podran contra nosotros");
                   int sele = e.nextInt();
                   if (sele== 1){
                      message = "Somos superiores";
                   }else{
                      message = "NO podran contra nosotros";
                   }
                   System.out.println("");
                  System.out.println(P2);
               
                    System.out.println("1.Somos superiores 2.NO podran contra nosotros");
                   int sele1 = e.nextInt();
                   if (sele1== 1){
                        message2 = "Somos superiores";
                   }else{
                      message2 = "NO podran contra nosotros";
                   }
                System.out.println("");
               System.out.println("Para poder completar la mision deberan derrotar a los enemigos  ");
               System.out.println("Sus enemigos son muy poderosos, tenga muchos cuidado, le deseamos exitos, contamos con ustedes");
               System.out.println("para ayudarlos un poco sus enemigos son los siguientes:");
               System.out.println("");
               System.out.println(nameA);
               System.out.println("Los datos del enemigo son: ");
               System.out.println("vida: "+liveA);
               System.out.println("daño de ataque: "+atackA);
               System.out.println("Habilidad especial: "+NamespHA);
               System.out.println("Daño de la habilidad especial: "+espHA);
               System.out.println("");
               System.out.println(name);
               System.out.println("Los datos del enemigo son: ");
               System.out.println("vida: "+live);
               System.out.println("daño de ataque: "+atack);
               System.out.println("Habilidad especial: "+NamespH);
               System.out.println("Daño de la habilidad especial: "+espH);
               System.out.println("Este villano cuenta con escudo de: "+shield);
               System.out.println("");
               int cant1 = 3;
               System.out.println("Hey!!! no te preocupes por ellos, ustedes tambien son poderosos");
               System.out.println("Sus datos son los siguientes");
               System.out.println("Para el heroe Guerrero");
               System.out.println("Vida: "+livegue);
               System.out.println("Daño de ataque: "+atackgue);
               System.out.println("Habilidad especial: "+itemsnamegue);
               System.out.println("Sanacion de: "+items3gue);
               System.out.println("Cantidad de usos para items: "+cant1);
               System.out.println("");
               int cant2= 2;
               System.out.println("Para el heroe Explorador");
               System.out.println("Vida: "+livexp);
               System.out.println("Daño de ataque: "+atackexp);
               System.out.println("Habilidad especial: "+itemsname);
               System.out.println("Segunda Habilidad especial: "+itemsname1);
               System.out.println("Sanacion de: "+items1exp);
               System.out.println("Daño de la segunda habilidad especial: "+items2exp);
                System.out.println("Cantidad de usos para items: "+cant2);
                      
               System.out.println("");
               System.out.println("Listo para combatir!!, Comienza la batalla!!");
               System.out.println("Turno del jugador 1");
                System.out.println("Que deseas realizar 1.ataque normal 2.habilidad especial");
                int op1 = e.nextInt();
                System.out.println("A que villano deseas combatir 1.Destructor 2.Invasor");
                int op1v=e.nextInt();
                
                if (op1==1 && op1v==1){
                    batallah1v1(live,atack, espH, shield);
                    
                }
               
           
           }
        }
    }
public static void Menu(){
       System.out.println(" ");
       System.out.println("--------------------------------------------------");
       System.out.println("Eliga una opcion"); 
       System.out.println("1.Start Game");
       System.out.println("2.Salir");
       System.out.println("-----------------------------------------------------");
}     
  public static void batallah1v1(int live,int atack,int espH,int shield){
      live = live -10;
      live
  }
}
