/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author diede
 */
public class Gue extends hero{
    int item3; 
    public Gue(int live, int atack, String itemsname, String name, int item3) {
        super(live, atack, itemsname,  name);
        this.item3 = item3;
    }

    public int getItem3() {
        return item3;
    }

    public void setItem3(int item3) {
        this.item3 = item3;
    }
    
}
